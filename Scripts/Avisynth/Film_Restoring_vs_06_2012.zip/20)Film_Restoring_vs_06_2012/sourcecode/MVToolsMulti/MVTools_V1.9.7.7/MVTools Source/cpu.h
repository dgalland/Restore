#ifndef MVT_CPU_H
#define MVT_CPU_H

unsigned int cpu_detect( void );

#endif
