// info (DrawString) header file

#ifndef __INFO_H__
#define __INFO_H__

#include "windows.h" 
#include "avisynth.h"

void DrawString(PVideoFrame &dst, int x, int y, const char *s); 

#endif
