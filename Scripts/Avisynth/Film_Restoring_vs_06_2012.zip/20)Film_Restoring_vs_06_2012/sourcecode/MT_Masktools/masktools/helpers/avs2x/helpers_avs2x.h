#ifndef __Mt_Helpers_Avs2x_H__
#define __Mt_Helpers_Avs2x_H__

namespace Filtering { namespace MaskTools { namespace Avs2x { namespace Helpers {

void DeclareHelpers(IScriptEnvironment *env);

} } } }

#endif