#ifndef __Mt_Common_H__
#define __Mt_Common_H__

#include "../../common/utils/utils.h"

#define MT_HAVE_BOOST_SPIRIT  /* compile define */
#define MT_HAVE_SOFTWIRE      /* compile define */

#endif
